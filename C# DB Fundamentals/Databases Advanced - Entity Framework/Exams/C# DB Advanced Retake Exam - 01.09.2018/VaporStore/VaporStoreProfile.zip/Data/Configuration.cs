﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=VaporStore;Trusted_Connection=True";
    }
}