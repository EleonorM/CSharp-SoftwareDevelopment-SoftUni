﻿namespace VaporStore.Data.Models
{
    public enum CardType
    {
        Debit = 0,
        Credit = 1
    }
}
