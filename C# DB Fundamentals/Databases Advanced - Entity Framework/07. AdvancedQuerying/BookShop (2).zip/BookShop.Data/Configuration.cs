﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=(localdb)\MSSQLLocalDB;Database=BookShop;Integrated Security=True;";
    }
}
